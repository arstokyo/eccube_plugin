<?php

namespace Plugin\AceClient\AceConfig\Model;

/**
 * Interface for Config Model
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
interface ConfigModelInterface
{
    
}
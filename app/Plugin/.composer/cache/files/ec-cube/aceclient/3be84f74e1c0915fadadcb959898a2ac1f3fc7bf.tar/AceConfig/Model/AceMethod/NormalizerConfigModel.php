<?php

namespace Plugin\AceClient\AceConfig\Model\AceMethod;

use Plugin\AceClient\AceConfig\Model\ConfigModelInterface;

/**
 * NormalizerConfigModel
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class NormalizerConfigModel extends InstanceConfigAbstract implements ConfigModelInterface
{

}


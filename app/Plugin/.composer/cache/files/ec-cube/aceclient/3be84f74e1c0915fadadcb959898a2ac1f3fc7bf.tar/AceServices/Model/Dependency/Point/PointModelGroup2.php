<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Point;

/**
 * Model for Point Group2
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class PointModelGroup2 extends PointModelGroup1 implements PointModelGroup2Interface
{
    use PointMaxTrait;
}
<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Reminder;

/**
 * Interface for PassWdRemModelInterface
 *
 * @author kmorino
 */
interface PassWdRemModelInterface extends HasQuestionInterface, HasAnswerInterface
{

}

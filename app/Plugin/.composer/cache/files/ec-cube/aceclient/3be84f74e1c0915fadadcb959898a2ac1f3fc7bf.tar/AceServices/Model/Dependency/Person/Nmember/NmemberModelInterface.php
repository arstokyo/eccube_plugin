<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Person\Nmember;

use Plugin\AceClient\AceServices\Model\Dependency\NoCategory\HasEdaInterface;

/**
 * Interface for Nmember
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
interface NmemberModelInterface extends HasEdaInterface
{

}
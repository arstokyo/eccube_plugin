<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Point;

/**
 * Interface for PointModel
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
interface PointModelInterface extends HasPointInterface
{

}
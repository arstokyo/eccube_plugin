<?php

namespace Plugin\AceClient\AceConfig\Model\AceMethod;

use Plugin\AceClient\AceConfig\Model\ConfigModelInterface;

/**
 * ApiClientConfigModel
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class ApiClientConfigModel extends InstanceConfigAbstract implements ConfigModelInterface
{

}

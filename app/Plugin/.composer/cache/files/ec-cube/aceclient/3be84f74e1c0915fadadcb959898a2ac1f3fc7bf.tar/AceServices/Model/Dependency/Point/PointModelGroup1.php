<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Point;

/**
 * Model for Point Group1
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class PointModelGroup1 implements PointModelGroup1Interface
{
    use PointMTrait,
        PointPTrait;
}
<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Card;

/**
 * Model for Card Level 2
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class CardModelLevel2 implements CardModelLevel2ExtractInterface
{
    use CardModelLevel2Trait;
}
<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Point;

/**
 * Class for PointModel
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class PointModel implements PointModelInterface
{
    use PointTrait;
}
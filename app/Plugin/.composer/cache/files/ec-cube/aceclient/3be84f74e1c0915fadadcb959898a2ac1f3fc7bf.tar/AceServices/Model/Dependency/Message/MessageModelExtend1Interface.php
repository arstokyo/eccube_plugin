<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Message;

/**
 * Interface for Message Model Extend2
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
interface MessageModelExtend1Interface extends MessageModelInterface, HasResultInterface
{

}
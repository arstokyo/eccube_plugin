<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Message;

/**
 * Class for Message Model Extend2
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class MessageModelExtend1 extends MessageModel implements MessageModelExtend1Interface
{
    use ResultTrait;
}
<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Point;

/**
 * Inteface for PointModelGroup2
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
interface PointModelGroup2Interface extends PointModelGroup1Interface, HasPointMaxInterface
{
    
}
<?php

namespace Plugin\AceClient\AceServices;

/**
 * Interface For AceService
 * 
 * @author Ars-Thong<v.t.nguyen@ar-sytem.co.jp>
 */
interface AceServiceInterface 
{
    
}
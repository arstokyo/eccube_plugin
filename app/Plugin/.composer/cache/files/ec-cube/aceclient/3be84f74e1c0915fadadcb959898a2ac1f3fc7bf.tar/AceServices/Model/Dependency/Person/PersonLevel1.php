<?php

namespace Plugin\AceClient\AceServices\Model\Dependency\Person;

/**
 * Class Person Level 1
 * 
 * @author Ars-Thong <v.t.nguyen@ar-system.co.jp>
 */
class PersonLevel1
{
   use PersonLevel1Trait;
}